import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flightsearch',
  templateUrl: './flightsearch.component.html',
  styleUrls: ['./flightsearch.component.css']
})
export class FlightsearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
