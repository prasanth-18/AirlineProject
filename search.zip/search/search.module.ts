import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';


@NgModule({
  declarations: [
    FlightsearchComponent
  ],
  imports: [
    CommonModule,
   
  ]
})
export class SearchModule { }
